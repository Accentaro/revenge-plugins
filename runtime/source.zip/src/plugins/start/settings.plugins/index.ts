import { ToastActionCreators } from '@revenge-mod/discord/actions'
import { onSettingsModulesLoaded } from '@revenge-mod/discord/modules/settings'
import { NetInfo } from '@revenge-mod/externals/react-native-community'
import { JsonStorageUpdateMode } from '@revenge-mod/json-storage'
import { registerInternalPlugin } from '@revenge-mod/plugins/_'
import {
    refreshAllRepos,
    updateAllPlugins,
} from '@revenge-mod/plugins/_/repositories'
import manifest from './manifest.json'
import { addDefaultRepoIfNeeded } from './repos'
import type { JsonStorage } from '@revenge-mod/json-storage'
import type { PluginApi } from '@revenge-mod/plugins/types'

export interface Storage {
    autoUpdate: boolean
    skipUpdatesOnExpensiveNetwork?: boolean
    lastUpdateCheck?: number
    defaultRepoRestored?: boolean
}

const OUTDATED_THRESHOLD = 60 * 60 * 1000 // 1 hour
const AUTO_UPDATE_CHECK_DELAY = 10_000

registerInternalPlugin<{ jsonStorage: Storage }>(manifest, {
    jsonStorage: {
        load: true,
        default: {
            autoUpdate: true,
        },
    },
    async start(api_) {
        api = api_

        // @as-require
        import('./plugins')

        onSettingsModulesLoaded(() => {
            // @as-require
            import('./register')
        })

        const settings = await api.jsonStorage.get()
        autoUpdateService(settings)
        defaultRepoRestoreService(settings, api.jsonStorage)
    },
})

function autoUpdateService(settings: Storage) {
    if (!settings.autoUpdate) return
    if (
        settings.lastUpdateCheck !== undefined &&
        Date.now() - settings.lastUpdateCheck <= OUTDATED_THRESHOLD
    )
        return

    setTimeout(async () => {
        try {
            if (settings.skipUpdatesOnExpensiveNetwork) {
                const { details } = await NetInfo.fetch()
                if (details?.isConnectionExpensive) return
            }

            const { errors } = await refreshAllRepos()
            await updateAllPlugins()

            if (!errors.length)
                await api.jsonStorage.set({
                    lastUpdateCheck: Date.now(),
                })
        } catch (e) {
            ToastActionCreators.open('REVENGE_PLUGIN_UPDATE_CHECK_FAILED', {
                text: 'Failed to check for plugin updates',
                variant: 'critical',
            })

            api.logger.warn('Failed to check for plugin updates', e)
        }
    }, AUTO_UPDATE_CHECK_DELAY)
}

function defaultRepoRestoreService(
    settings: Storage,
    storage: JsonStorage<Storage>,
) {
    if (!settings.defaultRepoRestored) addDefaultRepoIfNeeded()
    storage.subscribe((update, mode) => {
        // If user cleared storage, restore the default repo if needed
        if (mode === JsonStorageUpdateMode.Load && !update.defaultRepoRestored)
            addDefaultRepoIfNeeded()
    })
}

// Exposed for the Advanced settings screen (auto-update toggle)
export let api: PluginApi<{ jsonStorage: Storage }>
